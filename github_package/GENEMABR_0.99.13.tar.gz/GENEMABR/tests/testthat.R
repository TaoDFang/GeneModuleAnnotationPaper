library(testthat)
library(GENEMABR)

test_check("GENEMABR")
